extern int checkAccess(char *name,int access);
extern int setupDefaultContext(char *orig_file);
